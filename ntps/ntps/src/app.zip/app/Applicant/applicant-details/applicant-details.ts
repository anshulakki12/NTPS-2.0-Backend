import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../Shared/shared.module';
import { Router } from '@angular/router';
import { State } from '../../models/common-models';
import { MasterRegistration } from '../../Services/master-registration';

@Component({
  selector: 'app-applicant-details',
  standalone: true,
  imports: [SharedModule],
  templateUrl: './applicant-details.html',
  styleUrl: './applicant-details.css'
})
export class ApplicantDetails {
  detailsForm: FormGroup;
  fileError: string = '';
  selectedFile: File | null = null;

  states: State[] = [];
  circles: string[] = [];
  divisions: string[] = [];
  ranges: string[] = [];
  maxCommentLength = 200;
  constructor(private fb: FormBuilder, private router: Router,private registrationService: MasterRegistration) {
    this.detailsForm = this.fb.group({
      title: ['Mr.', Validators.required],
      name: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      email: ['', [Validators.required, Validators.email]],
      identityProof: ['', Validators.required],
      identityNumber: ['', Validators.required],
      state: ['', Validators.required],
      circle: ['', Validators.required],
      division: ['', Validators.required],
      range: ['', Validators.required],
      address: [''],
      pincode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]]
    });
  }
ngOnInit(): void {
  const userData = localStorage.getItem('loggedInUser');
  if (userData) {
    const user = JSON.parse(userData);

    // ✅ First patch values
    this.detailsForm.patchValue({
      title: user.nameTitle || 'Mr.',
      name: user.name,
      mobile: user.mobileNo,
      email: user.emailId
    });

    // ✅ Then disable fields (after values are set)
    this.detailsForm.get('title')?.disable({ emitEvent: false });
    this.detailsForm.get('name')?.disable({ emitEvent: false });
    this.detailsForm.get('mobile')?.disable({ emitEvent: false });
    this.detailsForm.get('email')?.disable({ emitEvent: false });
  }
  this.loadStates();
}


    onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        this.fileError = 'Only PDF files are allowed.';
        this.selectedFile = null;
      } else if (file.size > 2 * 1024 * 1024) {
        this.fileError = 'File size must not exceed 2MB.';
        this.selectedFile = null;
      } else {
        this.fileError = '';
        this.selectedFile = file;
      }
    }
  }

  onClear() {
    this.detailsForm.reset();
    this.selectedFile = null;
    this.fileError = '';
  }

  onSubmit() {
    if (this.detailsForm.invalid || !this.selectedFile) {
      this.fileError = this.selectedFile ? '' : 'Please upload valid PDF file.';
      this.detailsForm.markAllAsTouched();
      return;
    }

    const formData = new FormData();
    formData.append('details', JSON.stringify(this.detailsForm.value));
    formData.append('file', this.selectedFile);

    console.log('Form submitted:', formData);
    alert('Applicant details submitted successfully!');
    this.router.navigate(['/login']);
  }

  loadStates() {
    // ✅ Load states from API
    this.registrationService.getAllStates().subscribe({
      next: (data) => this.states = data,
      error: (err) => console.error('Error fetching states', err)
    });
  }
}
